USE buildings;
-- add sql queries under the appropriate comment

-- exercise 1
-- DESC order
SELECT name, city, height FROM skyscrapers ORDER BY completed_year;


-- exercise 2
SELECT name, completed_year, height FROM skyscrapers WHERE city = 'Milwaukee';


-- exercise 3
SELECT name, city, floors_above  FROM skyscrapers WHERE height > 300;


-- exercise 4
SELECT name FROM skyscrapers WHERE city = 'Nashville' AND completed_year > 0;


-- exercise 5
-- OR not AND
SELECT name, city FROM skyscrapers WHERE material = "steel" AND material = "contrete" ORDER BY name ASC;

-- exercise 6
-- missing check for completion
SELECT name, city ,floors_above FROM skyscrapers WHERE completed_year <= 1900 ORDER BY height ASC;


-- exercise 7
-- order first by city then completed_year
SELECT name FROM skyscrapers WHERE abandoned = 1  ORDER BY completed_year ASC;


-- exercise 8
-- missing ORDER BY clause
select DISTINCT material from skyscrapers;
