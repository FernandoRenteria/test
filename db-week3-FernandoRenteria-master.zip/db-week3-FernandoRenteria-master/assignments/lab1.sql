USE dreamhome;
-- add sql queries under the appropriate comment

-- exercise 1
SELECT propertyNo, type, rent FROM propertyForRent;
SELECT * FROM branch;
SELECT fName, lName, telNo FROM client;

-- exercise 2
SELECT propertyNo, street, city, type, rent as monthlyRent, rent*12 as annualRent FROM propertyForRent;


-- exercise 3
SELECT CONCAT( lName, ", ", fName) AS fullName FROM staff;

-- exercise 4
SELECT * FROM propertyForRent WHERE rent <= 400;
SELECT * FROM client WHERE prefType ="house";

SELECT * FROM viewing WHERE viewDate >= "2015-05-15";


-- exercise 5

SELECT fname, lName, branchNo FROM staff WHERE position = "Assistant" AND salary = 9000;
SELECT * FROM propertyForRent WHERE city = "Glasgow" AND rent< 400;
SELECT * FROM viewing WHERE viewDate >= "2015-04-01" AND viewDate <= "2015-04-30";

-- exercise 6
SELECT * FROM viewing ORDER BY viewDate;
SELECT * FROM viewing ORDER BY viewDate DESC;
SELECT * FROM viewing ORDER BY clientNo, viewDate;
