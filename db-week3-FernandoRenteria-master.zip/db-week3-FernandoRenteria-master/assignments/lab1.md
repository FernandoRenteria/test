# Lab 1 - SQL Select Queries

## Completing this assignment on the CaMS Front Server
1. Log into the front server using [Putty ](https://www.putty.org/)(Windows) or Terminal (Mac)

2. Clone the  assignment from GitHub  ` git clone url` where `url` is the URL of your GitHub repository
3. Open the `lab1.sql` script file using [WinSCP](https://winscp.net/eng/index.php)(Windows) or [Cyberduck](https://cyberduck.io/)(Mac)
2. On the server, log into the mysql command line using the command `mysql -p`
	- Password is your id# with  a "2" replacing the "L"
2. Copy each query from the mysql command line and paste into the script file open in WinSCP or Cyberduck.
4.  When you've completed the six exercises, save the `lab1.sql` file to the front server.
5.  On the server, commit and push your solutions to GitHub.
6.  Submit the assignment in Blackboard
```
cd lab1
git add .
git commit -m "completed lab 1"
git push
```
