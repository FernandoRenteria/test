# Selecting Rows

## Retrieving data with specific criteria
- Use a `WHERE` clause
- Example:
```sql
SELECT street, type FROM propertyForRent
WHERE  city = 'Glasgow';
```

### Comparison Operators
- Equality: `=`
- Less than: `<`
- Greater than: `>`
- Less than or equal to: `<=`
- Greater than or equal to: `>=`


### Example:  Comparison Search Condition
List all staff with a salary greater than 10,000.
```sql
SELECT staffNo, fName, lName, position, salary
FROM staff
WHERE salary > 10000;
```

### Comparing Data
- You can compare data of unlike types but it may produce unexpected results
- When comparing to a string literal or a date literal, you must enclose the literal in quotes
- Character comparisons are not case sensitive

### :question: Comparison – Exercises
- Find all property for rent with rent less than  or equal to $400
- Find all clients looking to rent a house
- Select all viewings since 2015-05-15.

## Relational Algebra: Selection (or Restriction)
- 𝜎(𝑅)
- Works on a single relation R and defines a relation that contains only those tuples (rows) of R that satisfy the specified condition (predicate).

### Example - Selection (or Restriction)
List all staff with a salary greater than $10,000.
𝜎(salary) >10000 (Staff)
![selection](images/selection.png)


## Compound Search Conditions
- Logical Operators
  - AND
  - OR
  - NOT
- Example
```sql
SELECT *
FROM propertyForRent
WHERE type="Flat" AND city="Glasgow";
```

###  Example: Compound Comparison Search Condition
List addresses of all branch offices in London or Glasgow.
```sql
SELECT *
FROM branch
WHERE city = 'London' OR city = 'Glasgow';
```

### :question: Compound Search Conditions – Exercises
- Find the first name, last name and branch number of all assistants whose salary is $9,000
- Find property for rent in Glasgow with rent less than $400
- Select all viewings in the month of April 2015

## Range Search
- Use the `BETWEEN` operator
- Compares the value of a test expression to see if it falls within the range of the given values
- `BETWEEN` test includes the endpoints of range.
- Example:
```sql
SELECT *
FROM viewing
WHERE viewDate BETWEEN "2015-04-01" AND "2015-04-30";
```
- Also a negated version `NOT BETWEEN`.
- `BETWEEN` does not add much to SQL’s expressive power.
  - Can use relational operators, as in the previous exercise

### Example: Range Search Condition
List all staff with a salary between 20,000 and 30,000.
```SQL
SELECT staffNo, fName, lName, position, salary
FROM staff
WHERE salary BETWEEN 20000 AND 30000;
```

## Set Membership
- `IN` operator
- Used to test whether a value is in a specified list of items
- There is a negated version (`NOT IN`).
- `IN` does not add much to SQL’s expressive power
- Use OR operator instead
-'IN' is more efficient when set contains many values.

### Example:  Set Membership
List all managers and supervisors.
```sql
SELECT staffNo, fName, lName, position
FROM staff
WHERE position IN ('Manager', 'Supervisor');
```

## Pattern Matching
- Uses `LIKE` and `NOT LIKE` and regular expressions
  - `%`: sequence of zero or more characters;
  - `_` (underscore): any single character.
- Can degrade performance so use sparingly
- Example: `LIKE '%Glasgow%;` means a sequence of characters of any length containing Glasgow.

### Example: Pattern Matching
Find all owners with the string ‘Glasgow’ in their address.
```sql
SELECT ownerNo, fName, lName, address, telNo
FROM privateOwner
WHERE address LIKE '%Glasgow%';
```

## Null Values
- Columns can contain a null value
- Value is empty or unknown
- Can test for null values using
IS NOT NULL
IS NULL

### Example:  NULL Search Condition
- List details of all viewings on property PG4 where a comment has not been supplied.
  - There are 2 viewings for property PG4, one with and one without a comment.
```sql  
SELECT clientNo, viewDate
FROM viewing
WHERE propertyNo = 'PG4' AND comment IS NULL;
```
