## Retrieving data in a particular order

## `ORDER BY` Clause
- Sorts the rows on one or more columns
- Default order is ascending
  - Can specify using the keyword `ASC`
  - Example: `ORDER BY lname` is the same as `ORDER BY lname ASC`
- To sort in descending order use the keyword `DESC`
  - Example: `ORDER BY lname DESC`

### Example: Single Column Ordering
List salaries for all staff, arranged in descending order of salary.
```sql
SELECT staffNo, fName, lName, salary
FROM staff
ORDER BY salary DESC;
```
### Example: Multiple Column Ordering
Produce abbreviated list of properties in order of property type.
```sql
SELECT propertyNo, type, rooms, rent
FROM propertyForRent
ORDER BY type;
```

### Example:  Multiple Column Ordering
- Four flats in this list - as no minor sort key specified, system arranges these rows in any order it chooses.
- To arrange in order of rent, specify minor order:
```sql
SELECT propertyNo, type, rooms, rent
FROM PropertyForRent
ORDER BY type, rent DESC;
```

### Sort by other criteria
- A column that uses an alias
- A calculation

### :question: Sorting Exercises
- Select viewings in ascending order by viewDate
- Repeat the above query but display in descending order
- Select viewings and display by client and within each client display by viewDate

## `LIMIT` Clause
- Specifies the maximum number of rows that are returned in the result set
- When combining `LIMIT` and `ORDER BY` you can select the n largest or n smallest values
- Example
```sql
SELECT fName, lName, position, salary
FROM staff
ORDER BY salary DESC
LIMIT 3;
```
