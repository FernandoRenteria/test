# MySQL

## History
- Developed in 1985 by MySQL AB
- Became open source in 2000
    - Was acquired by Sun Microsystems in 2008
    - Sun was acquired by Oracle in 2010
- Runs on a server and provides multi-user access
- Very popular especially for web applications
- We will use a fork of MySQL called  Maria DB

## Other RDBMS
- Oracle
- DB2
- SQL Server

## Using MySQL on the CS Server
- Log into the front server
- Log in to mysql `mysql -p`
- You will be prompted for a password which is your  id# with "2" replacing the "L"

### Listing the names of databases
To display all available databases, use the `show databases;` command at the MySQL command line
![](../images/db-list.png)

### Select a database for use
Once in MySQL, select the `dreamhome` database by using the using the `use` command
```
use dreamhome;
```
