# Introduction to SQL

### Structured Query Language  (SQL)
- A data sublanguage that has constructs for defining and processing a database
  - Create database and table structures
  - Perform basic data management chores (add, delete, and modify)
  - Perform complex queries to transform data into useful information
- It can be
  - Used stand-alone within a DBMS command line
  - Embedded in triggers and stored procedures
  - Used in scripting or programming languages

### SQL Categories
- Data Definition Language (DDL) is used to define database structures
- Data Manipulation Language (DML) is used to query and update data

### Writing SQL Statements
- SQL statement consists of reserved words and user-defined words.
- Reserved words are a fixed part of SQL and must be spelled exactly as required and cannot be split across lines.
- User-defined words are made up by user and represent names of various database objects such as relations, columns, views.
- SQL statements are not case sensitive
  - But fields, table names  and literals might be
- SQL statements must end with a semi-colon

### Literals
- Literals are constants used in SQL statements.
- All non-numeric literals must be enclosed in single quotes (e.g. `'Chicago'`).
- All numeric literals must **not** be enclosed in quotes (e.g. `650.00`).

### Coding Recommendations
- Capitalize all keywords.
- Use lowercase for the other code.
- Separate the words in names with underscores.
- Start each clause on a new line.
- Break long clauses into multiple lines.
- Indent continued lines.

*Note: Line breaks, white space, indentation, and capitalization have no effect on the operation of a statement.*


### Sample Database – Dreamhome
- Tables
  - branch
  - client
  - privateOwner
  - propertyForRent
  - registration
  - staff
  - viewing

### Getting Information about the Database
- To see the tables in a database use `SHOW TABLES;`
- To see the columns in a table
`SHOW COLUMNS FROM table_name`
  - Example: `SHOW COLUMNS FROM client;`
