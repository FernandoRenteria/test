# Basic `SELECT` statements

## Retrieving data
- Use the select statement
  - This is the most commonly used SQL statement
- Has 6 main clauses
  - `SELECT`	Specifies which columns are to appear in output.
  - `FROM`	Specifies table(s) to be used.
  - `WHERE` 	Filters rows.
  - `GROUP` BY	Forms groups of rows with same column value.
  - `HAVING`	Filters groups subject to some condition.
  - `ORDER` BY 	Specifies the order of the output.

## `SELECT` Statement
- Order of the clauses cannot be changed.
- Only `SELECT` and `FROM` are mandatory.

## Basic `SELECT` statement
- `SELECT field1, field2 FROM table;`
- Example:
  ```sql
  SELECT staffNo, fName, lName
  FROM staff;
  ```
- Use * to select all fields
```
SELECT *
FROM staff;
```
- Only use `*` when you need to retrieve all columns from a table.  

### Selecting Specific Columns, All Rows
Produce a list of salaries for all staff, showing only  staff number, first and last names, and salary.
```sql
SELECT staffNo, fName, lName, salary
FROM staff;
```

### :question: SELECT – Exercises
- Select the property number, type and rent from the propertyForRent table
- Select all fields from the branch table
- Select the name and phone of all clients

## Calculated Values
- You can use arithmetic in `SELECT` statements
- Operators
  -Multiplication: `*`
  - Division: `/`
  - Integer division: `DIV`
  - Modulo (remainder): `%` or `MOD` - Addition: `+`
  Subtraction: `-`
- Precedence
  - Multiplication, division, modulo
  - Addition, Subtraction
  - Can control using parenthesis

### Example: Calculated Fields
Produce list of monthly salaries for all staff, showing staff number, first/last name, and salary.

```sql
  SELECT staffNo, fName, lName, salary/12 FROM staff;
  ```

### Defining a Column Alias
- Renames a column heading in the result set
- Is useful with calculations
- Immediately follows the column name - there can also be the optional `AS` keyword between the column name and alias - Requires double quotation marks if it contains spaces or special characters or is case sensitive

### Example: Calculated Fields with Alias
```
SELECT staffNo, fName, lName, salary/12 AS monthlySalary
FROM staff;
```
### :question: Calculated Values – Exercise
Write a SELECT statement that returns this data from the propertyForRent table
- property number
- street address city type
- rent (alias monthlyRent)
- rent * 12 (alias annualRent)

## String Manipulation
- One important string manipulation function is `CONCAT`
- joins together two or more strings
```sql
 SELECT propertyNo, CONCAT(street, ", ", city, " ", postcode) as address
 FROM propertyForRent;
 ```

### :question: String Manipulation – Exercise
Write a SELECT statement that returns one column from the staff table named fullName that joins the staff member's first name and last like this:
`Doe, John`

## Duplicate Rows
- List the property numbers of all properties that have been viewed.
``` sql
SELECT propertyNo
FROM viewing;
```

### Use of `DISTINCT`
Use `DISTINCT` to eliminate duplicates:
```sql
 SELECT DISTINCT propertyNo
 FROM viewing;
 ```

## Relational Algebra

### Introduction
- Relational algebra and relational calculus are formal languages associated with the relational model.
- Informally, relational algebra is a (high-level) procedural language and relational calculus a non-procedural language.
- However, formally both are equivalent to one another.
- A language that produces a relation that can be derived using relational calculus is relationally complete.

### Relational Algebra
- Relational algebra operations work on one or more relations to define another relation without changing the original relations.
- Both operands and results are relations, so output from one operation can become input to another operation.
- Allows expressions to be nested, just as in arithmetic. This property is called **closure**.

### Operations
- Five basic operations in relational algebra: Selection, Projection, Cartesian product, Union,  and Set Difference.
- These perform most of the data retrieval operations needed.
- Also have Join, Intersection, and Division operations, which can be expressed in terms of 5 basic operations.

### Relational Algebra Operations
![operations](../images/operations.png)

### Projection
- Works on a single relation R and defines a relation that contains a vertical subset of R, extracting the values of specified attributes and eliminating duplicates.

### Example - Projection
Produce a list of salaries for all staff, showing only  staffNo, fName, lName, and salary details.

![projection](../images/projection.png)
