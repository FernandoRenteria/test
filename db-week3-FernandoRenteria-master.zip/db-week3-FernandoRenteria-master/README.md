
# Week 3 - Basic SQL Queries

## Lecture Notes
- [MySQL](notes/mysql.md)
- [Introduction to SQL](notes/sql-intro.md)
- [Basic Select Queries](notes/select.md)
- [Selecting rows](notes/where.md)
- [Ordering results](notes/order-by.md)

## Assignments
- [Lab Assignment 1](assignments/lab1.md)
- [Assignment 3](assignments/assign3.md)

As you complete these assignments, commit and push your solution to GitHub.

After you have pushed your changes to GitHub, submit the related assignment in Blackboard.  You do not have to attach anything to the assignment in Blackboard, just press the submit button.  When you submit the assignment in Blackboard, I will know that it is ready to be graded.
